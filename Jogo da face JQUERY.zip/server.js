var http = require('http');
var fs = require('fs');

var server = http.createServer(function(req, res) {
  if (req.url === "/jquerySMILEGAME") {
    fs.readFile('projetos/projetofinal/jogo.html',function (err, data){
        res.writeHead(200, {'Content-Type': 'text/html','Content-Length':data.length});
        res.write(data);
        res.end();
    });
  } else {
    res.end('<h1>Regras do jogo: <a href="/jquerySMILEGAME">Jogo</a></h1>');
  }
}).listen(3000)
